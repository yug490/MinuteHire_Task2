# LearnAI — End-to-end ASP.NET Core + DevExtreme project

This is a single ASP.NET Core application serving a DevExtreme/jQuery frontend from `wwwroot` and a JWT-protected REST API. It targets .NET 10. Use Visual Studio 2026 (version 18.0 or newer) with the .NET 10 SDK.

## Requirements
- Visual Studio 2026 (version 18.0 or newer) with the .NET 10 SDK
- SQL Server / SQL Server Express and SSMS
- Internet access for the DevExtreme and jQuery CDN assets
- A Google Gemini API key for live AI answers (OpenAI is also supported)

## Run in Visual Studio
1. Extract the ZIP and open `AISmartLearning.API/AISmartLearning.API.csproj`.
2. In `appsettings.json`, change `ConnectionStrings:DefaultConnection` to your SQL Server instance. Example SQL Express: `Server=\\.\SQLEXPRESS;Database=AISmartLearningDB;Integrated Security=True;TrustServerCertificate=True;MultipleActiveResultSets=True`.
3. Ensure the JWT signing key is at least 32 characters. For local use, the appsettings file includes a development-only key; replace it before sharing/deployment.
4. Restore NuGet packages, then Build > Rebuild Solution.
5. Set the project as startup and press F5. Open `http://localhost:5190` (or the URL shown in Visual Studio). Swagger is at `/swagger` in Development.

On startup, the app attempts `EnsureCreated` and seeds the Admin/Teacher/Student demo users if the database is new/compatible. `EnsureCreated` does not migrate an existing database. If the database already exists with a different schema, back it up and reconcile the schema before testing.

## Demo credentials
- Admin: `admin@aismartlearning.local` / `Admin123!ChangeMe`
- Teacher: `teacher@aismartlearning.local` / `Teacher123!ChangeMe`
- Student: `student@aismartlearning.local` / `Student123!ChangeMe`

If seeding fails, inspect the Visual Studio Output window and SQL Server connection. Do not assume credentials exist unless the seed completed.

## Included features
- Responsive login screen with role-specific navigation
- JWT login and authenticated `/api/auth/me`
- Backend `[Authorize(Roles=...)]` enforcement for Admin and Student/Teacher APIs
- DevExtreme DataGrid for account management, activity logs and conversation history
- AJAX/fetch calls to the REST API
- Conversation persistence, AI-provider integration, optional browser speech input
- Swagger and SQL/ER diagram files

## AI configuration (Semantic Kernel)
The project uses Microsoft Semantic Kernel as the LLM orchestration/client library. The default provider is Google Gemini, using the Semantic Kernel Google connector; OpenAI is also supported. The Google connector is currently marked prerelease/experimental by Microsoft, so NuGet may show prerelease-package warnings.

1. Create a Gemini key at https://aistudio.google.com/app/apikey.
2. In Visual Studio, right-click `AISmartLearning.API` > **Manage User Secrets**.
3. Add the following JSON, replacing the placeholder with your private key:

```json
{
  "AI": {
    "Provider": "Gemini",
    "Model": "gemini-3-flash-preview",
    "ApiKey": "YOUR_GEMINI_API_KEY"
  }
}
```

For OpenAI, set `Provider` to `OpenAI`, `Model` to a model enabled for your account (for example `gpt-4o-mini`) and `ApiKey` to your OpenAI key. Never commit API keys to source control. Restart the application after changing User Secrets. If a provider request fails, the API returns a diagnostic message and the server log records the exception. A valid key, model access, quota and internet connectivity are required for real responses.

## API endpoints
- `POST /api/auth/login`, `GET /api/auth/me`, Admin-only `POST /api/auth/register`
- `GET /api/dashboard/summary`
- Student/Teacher: `GET/POST /api/conversations`, `GET /api/conversations/{id}/messages`, `POST /api/conversations/{id}/messages`
- Admin: `GET /api/admin/users`, `PATCH /api/admin/users/{id}/status`, `GET /api/admin/logs`
- `GET /api/health`

## Important
DevExtreme assets are loaded from the DevExtreme CDN and require internet access. This source package was updated to target .NET 10, but has not been compiled or run in this environment; verify with Build > Rebuild Solution and test the APIs locally before submission.


### AI response latency
The AI service reuses the Semantic Kernel instance between requests and sends a shorter recent conversation history (last 6 messages) with concise tutoring instructions. This reduces avoidable overhead and prompt size. Actual response time still depends on Gemini 3 Flash Preview availability, provider latency, network connection, and quota. The chat UI disables duplicate sends while a request is in progress.


### AI voice responses
In the chat header, click **Voice replies off** to enable **Voice replies on**. New AI answers will then be read aloud using the browser built-in speech synthesis; no separate TTS API key is required. Speech recognition still uses the browser Web Speech API and requires microphone permission. Browser/OS voice availability and language depend on the client device.


### DevExtreme grid loading note
The UI uses DevExtreme DataGrid when its CDN scripts load. A small fallback table renderer is included so User Management, Activity Logs, and Conversation History remain usable if the DevExtreme CDN is blocked or unavailable. For the full DevExtreme widgets, allow access to `cdn3.devexpress.com`.


### Build troubleshooting (Visual Studio / .NET 10)

If Visual Studio reports an `MSB3027`/`MSB3021` error copying
`Microsoft.CodeAnalysis.Workspaces.MSBuild.BuildHost.runtimeconfig.json`, close the running app,
then use **Build > Clean Solution**, close Visual Studio, and delete the API project's `bin` and
`obj` folders. Reopen the project and restore NuGet packages before rebuilding.

The API project does not require `Microsoft.EntityFrameworkCore.Design` at runtime, so that
package reference is omitted to avoid bringing the design-time MSBuild/Roslyn BuildHost into
the app's output-copy step. If you later choose to manage EF migrations from Visual Studio, add
the matching `Microsoft.EntityFrameworkCore.Design` 10.0.x package back as a development-only
tooling dependency.
