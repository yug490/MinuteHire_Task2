```mermaid
erDiagram
 Roles ||--o{ Users : assigns
 Users ||--o{ Conversations : owns
 Conversations ||--o{ ConversationMessages : contains
 Users ||--o{ InteractionLogs : generates
 Conversations o|--o{ InteractionLogs : relates_to
 Roles { int RoleId PK string RoleName UK }
 Users { int UserId PK string FullName string Email UK string PasswordHash int RoleId FK bool IsActive datetime CreatedAt }
 Conversations { int ConversationId PK int UserId FK string Title datetime StartedAt datetime EndedAt string Status }
 ConversationMessages { long MessageId PK int ConversationId FK string SenderType string MessageText datetime CreatedAt }
 InteractionLogs { long LogId PK int UserId FK int ConversationId FK string Action string Details datetime CreatedAt }
```